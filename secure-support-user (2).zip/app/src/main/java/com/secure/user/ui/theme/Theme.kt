package com.secure.user.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

private val SsColorScheme = darkColorScheme(
    primary = SsRed,
    onPrimary = Color.White,
    background = SsBackground,
    onBackground = SsTextPrimary,
    surface = SsSurface,
    onSurface = SsTextPrimary,
    surfaceVariant = SsSurfaceHigh,
    onSurfaceVariant = SsTextSecondary,
    outline = SsOutline,
    error = SsRed
)

private val SsTypography = Typography(
    headlineMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Bold,
        fontSize = 28.sp
    ),
    titleLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Bold,
        fontSize = 20.sp
    ),
    titleMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 16.sp
    ),
    bodyMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontSize = 14.sp,
        lineHeight = 20.sp
    ),
    bodySmall = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontSize = 12.sp,
        lineHeight = 16.sp
    )
)

@Composable
fun SecureSupportTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = SsColorScheme,
        typography = SsTypography,
        content = content
    )
}
