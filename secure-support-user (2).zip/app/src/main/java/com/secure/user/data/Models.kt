package com.secure.user.data

enum class ApprovalStatus { PENDING, APPROVED, REJECTED }

enum class SessionStatus { COMPLETED, CANCELLED, DISCONNECTED, EXPIRED }

data class SupportSession(
    val sessionId: String,
    val date: String,
    val startTime: String,
    val endTime: String,
    val duration: String,
    val status: SessionStatus
)
