package com.secure.user.ui.screens

import android.content.Context
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.BorderStroke
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.RestartAlt
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.secure.user.ui.components.ScreenHeader
import com.secure.user.ui.components.SsCard
import com.secure.user.ui.components.StatusLabel
import com.secure.user.ui.theme.SsGray
import com.secure.user.ui.theme.SsGreen
import com.secure.user.ui.theme.SsOutline
import com.secure.user.ui.theme.SsRed
import com.secure.user.ui.theme.SsSurface
import com.secure.user.ui.theme.SsTextPrimary
import com.secure.user.ui.theme.SsTextSecondary

@Composable
fun SettingsScreen(deviceId: String, isOnline: Boolean, onReset: () -> Unit) {
    val context = LocalContext.current
    val versionName = remember { appVersion(context) }
    var confirmReset by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        ScreenHeader(title = "Settings", subtitle = "Secure Support User")

        SectionCard("Device") {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Device ID", color = SsTextSecondary, fontSize = 14.sp)
                Text(
                    deviceId,
                    color = SsTextPrimary,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 14.sp
                )
            }
            Divider(color = SsOutline, modifier = Modifier.padding(vertical = 12.dp))
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Connection Status", color = SsTextSecondary, fontSize = 14.sp)
                if (isOnline) StatusLabel("Online", SsGreen) else StatusLabel("Offline", SsGray)
            }
        }

        SectionCard("Privacy Information") {
            Text(
                "Screen sharing occurs only after your explicit consent. Android will show its " +
                    "own screen-capture permission prompt, and a notification stays visible for as " +
                    "long as sharing is active. You can stop a session at any time. " +
                    "This app does not record or store your screen.",
                color = SsTextSecondary,
                fontSize = 13.sp,
                lineHeight = 19.sp
            )
        }

        SectionCard("Support Information") {
            Text(
                "Support sessions are started only by an authorized administrator, and only " +
                    "after this device has been approved and you have accepted the request.",
                color = SsTextSecondary,
                fontSize = 13.sp,
                lineHeight = 19.sp
            )
        }

        SectionCard("App Information") {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Version", color = SsTextSecondary, fontSize = 14.sp)
                Text(versionName, color = SsTextPrimary, fontSize = 14.sp)
            }
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Application ID", color = SsTextSecondary, fontSize = 14.sp)
                Text(context.packageName, color = SsTextPrimary, fontSize = 14.sp)
            }
        }

        OutlinedButton(
            onClick = { confirmReset = true },
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp),
            shape = RoundedCornerShape(14.dp),
            border = BorderStroke(1.dp, SsRed),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = SsRed)
        ) {
            Icon(Icons.Outlined.RestartAlt, null, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(8.dp))
            Text("Reset Device Registration", fontWeight = FontWeight.SemiBold)
        }
    }

    if (confirmReset) {
        AlertDialog(
            onDismissRequest = { confirmReset = false },
            confirmButton = {
                TextButton(onClick = {
                    confirmReset = false
                    onReset()
                }) { Text("Reset", color = SsRed) }
            },
            dismissButton = {
                TextButton(onClick = { confirmReset = false }) {
                    Text("Cancel", color = SsTextSecondary)
                }
            },
            title = { Text("Reset device registration?") },
            text = {
                Text(
                    "A new Device ID will be generated and this device will need administrator " +
                        "approval again."
                )
            },
            containerColor = SsSurface,
            titleContentColor = SsTextPrimary,
            textContentColor = SsTextSecondary
        )
    }
}

@Composable
private fun SectionCard(title: String, content: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit) {
    SsCard {
        Text(title, color = SsTextPrimary, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(12.dp))
        content()
    }
}

private fun appVersion(context: Context): String = try {
    context.packageManager.getPackageInfo(context.packageName, 0).versionName ?: "1.0"
} catch (e: Exception) {
    "1.0"
}
