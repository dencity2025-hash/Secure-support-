package com.secure.user.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.ErrorOutline
import androidx.compose.material.icons.outlined.PhoneAndroid
import androidx.compose.material.icons.outlined.ScreenShare
import androidx.compose.material.icons.outlined.Schedule
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.secure.user.data.ApprovalStatus
import com.secure.user.ui.components.ScreenHeader
import com.secure.user.ui.components.SsCard
import com.secure.user.ui.components.StatusLabel
import com.secure.user.ui.theme.SsAmber
import com.secure.user.ui.theme.SsGray
import com.secure.user.ui.theme.SsGreen
import com.secure.user.ui.theme.SsRed
import com.secure.user.ui.theme.SsOutline
import com.secure.user.ui.theme.SsSurface
import com.secure.user.ui.theme.SsSurfaceHigh
import com.secure.user.ui.theme.SsTextPrimary
import com.secure.user.ui.theme.SsTextSecondary

@Composable
fun HomeScreen(deviceId: String, isOnline: Boolean, approval: ApprovalStatus) {
    val clipboard = LocalClipboardManager.current
    var showInfo by remember { mutableStateOf(false) }

    val approvalColor = when (approval) {
        ApprovalStatus.PENDING -> SsAmber
        ApprovalStatus.APPROVED -> SsGreen
        ApprovalStatus.REJECTED -> SsRed
    }
    val approvalText = when (approval) {
        ApprovalStatus.PENDING -> "Pending"
        ApprovalStatus.APPROVED -> "Approved"
        ApprovalStatus.REJECTED -> "Rejected"
    }
    val supportMessage = when (approval) {
        ApprovalStatus.PENDING -> "Waiting for administrator approval..."
        ApprovalStatus.APPROVED -> "Approved. Waiting for a support request."
        ApprovalStatus.REJECTED -> "This device was rejected by the administrator."
    }
    val supportIcon = when (approval) {
        ApprovalStatus.PENDING -> Icons.Outlined.Schedule
        ApprovalStatus.APPROVED -> Icons.Outlined.CheckCircle
        ApprovalStatus.REJECTED -> Icons.Outlined.ErrorOutline
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        ScreenHeader(title = "Secure Support", subtitle = "User Application")

        SsCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(SsSurfaceHigh),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Outlined.PhoneAndroid, null, tint = SsTextPrimary)
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("Device ID", color = SsTextSecondary, fontSize = 12.sp)
                    Text(
                        deviceId,
                        color = SsTextPrimary,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
                IconButton(onClick = { clipboard.setText(AnnotatedString(deviceId)) }) {
                    Icon(Icons.Outlined.ContentCopy, "Copy device ID", tint = SsTextSecondary)
                }
            }
            Divider(color = SsOutline, modifier = Modifier.padding(vertical = 14.dp))
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Connection Status", color = SsTextSecondary, fontSize = 14.sp)
                if (isOnline) StatusLabel("Online", SsGreen) else StatusLabel("Offline", SsGray)
            }
            Spacer(Modifier.height(12.dp))
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Approval Status", color = SsTextSecondary, fontSize = 14.sp)
                StatusLabel(approvalText, approvalColor)
            }
        }

        Button(
            onClick = { showInfo = true },
            modifier = Modifier
                .fillMaxWidth()
                .height(76.dp)
                .shadow(
                    elevation = 20.dp,
                    shape = RoundedCornerShape(18.dp),
                    ambientColor = SsRed,
                    spotColor = SsRed
                ),
            shape = RoundedCornerShape(18.dp),
            colors = ButtonDefaults.buttonColors(containerColor = SsRed, contentColor = Color.White)
        ) {
            Icon(Icons.Outlined.ScreenShare, null, modifier = Modifier.size(30.dp))
            Spacer(Modifier.width(14.dp))
            Column {
                Text("Live Support", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text("Live Screen Mirror", fontSize = 13.sp, color = Color.White.copy(alpha = 0.85f))
            }
        }

        SsCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(supportIcon, null, tint = approvalColor, modifier = Modifier.size(32.dp))
                Spacer(Modifier.width(14.dp))
                Column {
                    Text(
                        "Support Status",
                        color = SsTextPrimary,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(supportMessage, color = SsTextSecondary, fontSize = 13.sp)
                }
            }
        }
    }

    if (showInfo) {
        val body = if (approval == ApprovalStatus.APPROVED) {
            "An administrator starts a session by sending you a request. " +
                "You will always be asked before your screen is shared, and you can stop at any time."
        } else {
            "Live Support becomes available once an administrator approves this device. " +
                "Give the administrator your Device ID so they can find it."
        }
        AlertDialog(
            onDismissRequest = { showInfo = false },
            confirmButton = {
                TextButton(onClick = { showInfo = false }) { Text("OK", color = SsRed) }
            },
            title = { Text("Live Support") },
            text = { Text(body) },
            containerColor = SsSurface,
            titleContentColor = SsTextPrimary,
            textContentColor = SsTextSecondary
        )
    }
}
