package com.secure.user.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.History
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.secure.user.data.SessionStatus
import com.secure.user.data.SupportSession
import com.secure.user.ui.components.ScreenHeader
import com.secure.user.ui.components.SsCard
import com.secure.user.ui.components.StatusLabel
import com.secure.user.ui.theme.SsAmber
import com.secure.user.ui.theme.SsGray
import com.secure.user.ui.theme.SsGreen
import com.secure.user.ui.theme.SsRed
import com.secure.user.ui.theme.SsTextPrimary
import com.secure.user.ui.theme.SsTextSecondary

private fun SessionStatus.label(): String = when (this) {
    SessionStatus.COMPLETED -> "Completed"
    SessionStatus.CANCELLED -> "Cancelled"
    SessionStatus.DISCONNECTED -> "Disconnected"
    SessionStatus.EXPIRED -> "Expired"
}

private fun SessionStatus.color(): Color = when (this) {
    SessionStatus.COMPLETED -> SsGreen
    SessionStatus.CANCELLED -> SsGray
    SessionStatus.DISCONNECTED -> SsRed
    SessionStatus.EXPIRED -> SsAmber
}

@Composable
fun HistoryScreen(sessions: List<SupportSession>) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp, vertical = 12.dp)
    ) {
        ScreenHeader(title = "History", subtitle = "Support sessions")
        Spacer(Modifier.height(16.dp))

        if (sessions.isEmpty()) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        Icons.Outlined.History,
                        contentDescription = null,
                        tint = SsGray,
                        modifier = Modifier.size(56.dp)
                    )
                    Spacer(Modifier.height(12.dp))
                    Text(
                        "No support sessions yet",
                        color = SsTextPrimary,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "Completed, cancelled and expired sessions will appear here.",
                        color = SsTextSecondary,
                        fontSize = 13.sp,
                        textAlign = TextAlign.Center
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(sessions, key = { it.sessionId }) { session ->
                    SessionCard(session)
                }
            }
        }
    }
}

@Composable
private fun SessionCard(session: SupportSession) {
    SsCard {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                session.sessionId,
                color = SsTextPrimary,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                fontSize = 15.sp
            )
            StatusLabel(session.status.label(), session.status.color())
        }
        Spacer(Modifier.height(8.dp))
        Text(
            "${session.date}  ${session.startTime} - ${session.endTime}  (${session.duration})",
            color = SsTextSecondary,
            fontSize = 13.sp
        )
    }
}
