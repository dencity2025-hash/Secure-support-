package com.secure.user

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.secure.user.ui.SecureSupportRoot
import com.secure.user.ui.theme.SecureSupportTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            SecureSupportTheme {
                SecureSupportRoot()
            }
        }
    }
}
