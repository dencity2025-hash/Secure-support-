package com.secure.user.data

import android.content.Context
import java.security.SecureRandom

/**
 * Generates and persists the device ID (format SSU-XXXX-XXXX-XXXX).
 * The ID is created once with SecureRandom and re-used on every launch.
 */
class DeviceIdStore(context: Context) {

    private val prefs = context.applicationContext
        .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    @Synchronized
    fun getOrCreate(): String {
        val existing = prefs.getString(KEY_DEVICE_ID, null)
        if (existing != null && isValid(existing)) return existing
        val id = generate()
        prefs.edit().putString(KEY_DEVICE_ID, id).commit()
        return id
    }

    /** Removes the stored ID and creates a fresh one. */
    @Synchronized
    fun reset(): String {
        prefs.edit().remove(KEY_DEVICE_ID).commit()
        return getOrCreate()
    }

    companion object {
        private const val PREFS_NAME = "secure_support_device"
        private const val KEY_DEVICE_ID = "device_id"

        // No 0/O/1/I so IDs are easy to read out over the phone.
        private const val ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        private val PATTERN = Regex("^SSU(-[A-Z0-9]{4}){3}$")
        private val random = SecureRandom()

        fun generate(): String {
            fun block(): String = buildString {
                repeat(4) { append(ALPHABET[random.nextInt(ALPHABET.length)]) }
            }
            return "SSU-${block()}-${block()}-${block()}"
        }

        fun isValid(id: String): Boolean = PATTERN.matches(id)
    }
}
