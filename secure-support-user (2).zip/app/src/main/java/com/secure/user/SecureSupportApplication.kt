package com.secure.user

import android.app.Application
import android.util.Log
import com.google.firebase.FirebaseApp

class SecureSupportApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        // The google-services plugin initialises Firebase automatically from google-services.json.
        // This only confirms which project the app is bound to.
        runCatching { FirebaseApp.getInstance() }
            .onSuccess { Log.i(TAG, "Firebase ready, project = ${it.options.projectId}") }
            .onFailure { Log.e(TAG, "Firebase is not initialised. Check app/google-services.json.") }
    }

    private companion object {
        const val TAG = "SecureSupport"
    }
}
