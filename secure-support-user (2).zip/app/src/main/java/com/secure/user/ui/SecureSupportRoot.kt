package com.secure.user.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.secure.user.ui.screens.HistoryScreen
import com.secure.user.ui.screens.HomeScreen
import com.secure.user.ui.screens.SettingsScreen
import com.secure.user.ui.screens.SplashScreen
import com.secure.user.ui.theme.SsBackground
import com.secure.user.ui.theme.SsGray
import com.secure.user.ui.theme.SsRed
import com.secure.user.ui.theme.SsSurface

private object Routes {
    const val SPLASH = "splash"
    const val HOME = "home"
    const val HISTORY = "history"
    const val SETTINGS = "settings"
}

private data class BottomItem(
    val route: String,
    val label: String,
    val icon: ImageVector,
    val selectedIcon: ImageVector
)

private val bottomItems = listOf(
    BottomItem(Routes.HOME, "Home", Icons.Outlined.Home, Icons.Filled.Home),
    BottomItem(Routes.HISTORY, "History", Icons.Outlined.History, Icons.Filled.History),
    BottomItem(Routes.SETTINGS, "Settings", Icons.Outlined.Settings, Icons.Filled.Settings)
)

@Composable
fun SecureSupportRoot(viewModel: MainViewModel = viewModel()) {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route

    val deviceId by viewModel.deviceId.collectAsStateWithLifecycle()
    val isOnline by viewModel.isOnline.collectAsStateWithLifecycle()
    val approval by viewModel.approval.collectAsStateWithLifecycle()
    val sessions by viewModel.sessions.collectAsStateWithLifecycle()

    Scaffold(
        containerColor = SsBackground,
        bottomBar = {
            if (currentRoute != null && currentRoute != Routes.SPLASH) {
                SsBottomBar(currentRoute, navController)
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Routes.SPLASH,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Routes.SPLASH) {
                SplashScreen(onFinished = {
                    navController.navigate(Routes.HOME) {
                        popUpTo(Routes.SPLASH) { inclusive = true }
                    }
                })
            }
            composable(Routes.HOME) {
                HomeScreen(deviceId = deviceId, isOnline = isOnline, approval = approval)
            }
            composable(Routes.HISTORY) {
                HistoryScreen(sessions = sessions)
            }
            composable(Routes.SETTINGS) {
                SettingsScreen(
                    deviceId = deviceId,
                    isOnline = isOnline,
                    onReset = viewModel::resetDeviceRegistration
                )
            }
        }
    }
}

@Composable
private fun SsBottomBar(currentRoute: String, navController: NavController) {
    NavigationBar(containerColor = SsSurface) {
        bottomItems.forEach { item ->
            val selected = currentRoute == item.route
            NavigationBarItem(
                selected = selected,
                onClick = {
                    if (!selected) {
                        navController.navigate(item.route) {
                            popUpTo(Routes.HOME) { saveState = true }
                            launchSingleTop = true
                            restoreState = true
                        }
                    }
                },
                icon = {
                    Icon(if (selected) item.selectedIcon else item.icon, contentDescription = item.label)
                },
                label = { Text(item.label) },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = SsRed,
                    selectedTextColor = SsRed,
                    indicatorColor = SsRed.copy(alpha = 0.15f),
                    unselectedIconColor = SsGray,
                    unselectedTextColor = SsGray
                )
            )
        }
    }
}
