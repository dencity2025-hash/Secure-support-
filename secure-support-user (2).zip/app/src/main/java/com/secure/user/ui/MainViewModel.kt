package com.secure.user.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.secure.user.data.ApprovalStatus
import com.secure.user.data.DeviceIdStore
import com.secure.user.data.NetworkMonitor
import com.secure.user.data.SupportSession
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val deviceIdStore = DeviceIdStore(app)

    private val _deviceId = MutableStateFlow(deviceIdStore.getOrCreate())
    val deviceId: StateFlow<String> = _deviceId.asStateFlow()

    val isOnline: StateFlow<Boolean> = NetworkMonitor(app).isOnline
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), false)

    // Phase 1: fixed at the initial value. Phase 2 will read this from Firestore devices/{deviceId}.
    private val _approval = MutableStateFlow(ApprovalStatus.PENDING)
    val approval: StateFlow<ApprovalStatus> = _approval.asStateFlow()

    // Phase 1: no sessions exist yet. Phase 5 will load them from Firestore.
    private val _sessions = MutableStateFlow<List<SupportSession>>(emptyList())
    val sessions: StateFlow<List<SupportSession>> = _sessions.asStateFlow()

    fun resetDeviceRegistration() {
        _deviceId.value = deviceIdStore.reset()
        _approval.value = ApprovalStatus.PENDING
    }
}
