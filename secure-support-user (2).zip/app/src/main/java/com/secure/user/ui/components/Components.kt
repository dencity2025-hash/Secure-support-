package com.secure.user.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.PhoneAndroid
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.secure.user.ui.theme.SsOutline
import com.secure.user.ui.theme.SsRed
import com.secure.user.ui.theme.SsRedDark
import com.secure.user.ui.theme.SsSurface
import com.secure.user.ui.theme.SsTextPrimary
import com.secure.user.ui.theme.SsTextSecondary

/** Red shield with a soft glow behind it. [glow] scales the glow intensity (0f..1f). */
@Composable
fun ShieldLogo(logoSize: Dp, modifier: Modifier = Modifier, glow: Float = 1f) {
    Box(modifier.size(logoSize), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            drawCircle(
                brush = Brush.radialGradient(
                    listOf(SsRed.copy(alpha = 0.40f * glow), Color.Transparent)
                ),
                radius = size.minDimension / 2f
            )
            val shield = Path().apply {
                moveTo(w * 0.5f, h * 0.12f)
                lineTo(w * 0.82f, h * 0.24f)
                lineTo(w * 0.82f, h * 0.52f)
                cubicTo(w * 0.82f, h * 0.72f, w * 0.66f, h * 0.86f, w * 0.5f, h * 0.92f)
                cubicTo(w * 0.34f, h * 0.86f, w * 0.18f, h * 0.72f, w * 0.18f, h * 0.52f)
                lineTo(w * 0.18f, h * 0.24f)
                close()
            }
            drawPath(
                path = shield,
                brush = Brush.verticalGradient(
                    listOf(SsRed.copy(alpha = 0.28f), SsRedDark.copy(alpha = 0.08f))
                )
            )
            drawPath(
                path = shield,
                color = SsRed,
                style = Stroke(width = w * 0.045f, join = StrokeJoin.Round)
            )
        }
        Icon(
            imageVector = Icons.Outlined.PhoneAndroid,
            contentDescription = null,
            tint = Color.White,
            modifier = Modifier.size(logoSize * 0.3f)
        )
    }
}

@Composable
fun StatusDot(color: Color, modifier: Modifier = Modifier, dotSize: Dp = 10.dp) {
    Box(modifier.size(dotSize).clip(CircleShape).background(color))
}

@Composable
fun StatusLabel(text: String, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        StatusDot(color)
        Spacer(Modifier.width(6.dp))
        Text(text, color = color, fontSize = 14.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun SsCard(
    modifier: Modifier = Modifier,
    borderColor: Color = SsOutline,
    containerColor: Color = SsSurface,
    content: @Composable ColumnScope.() -> Unit
) {
    val shape = RoundedCornerShape(16.dp)
    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(shape)
            .background(containerColor)
            .border(1.dp, borderColor, shape)
            .padding(16.dp),
        content = content
    )
}

@Composable
fun ScreenHeader(
    title: String,
    subtitle: String,
    modifier: Modifier = Modifier,
    trailing: @Composable () -> Unit = {}
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ShieldLogo(logoSize = 44.dp, glow = 0.6f)
        Column(Modifier.weight(1f)) {
            Text(title, color = SsTextPrimary, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text(subtitle, color = SsTextSecondary, fontSize = 13.sp)
        }
        trailing()
    }
}
