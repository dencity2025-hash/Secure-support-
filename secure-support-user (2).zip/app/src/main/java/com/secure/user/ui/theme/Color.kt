package com.secure.user.ui.theme

import androidx.compose.ui.graphics.Color

val SsBackground = Color(0xFF07090F)
val SsSurface = Color(0xFF0F131C)
val SsSurfaceHigh = Color(0xFF171C28)
val SsOutline = Color(0xFF252C3B)
val SsRed = Color(0xFFE5202E)
val SsRedDark = Color(0xFFA80F1B)
val SsGreen = Color(0xFF22C55E)
val SsAmber = Color(0xFFF5B301)
val SsGray = Color(0xFF7A8294)
val SsTextPrimary = Color(0xFFF5F7FA)
val SsTextSecondary = Color(0xFFA3ABBA)
