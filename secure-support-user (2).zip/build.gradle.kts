// Top-level build file. Versions are chosen to work with Gradle 7.4.x (used by Android Code Studio).
plugins {
    id("com.android.application") version "7.3.1" apply false
    id("org.jetbrains.kotlin.android") version "1.8.22" apply false
    id("com.google.gms.google-services") version "4.3.15" apply false
}
